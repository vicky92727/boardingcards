<?php
/**
 * Abstract class for card
 * 
 */
namespace trip\assets;

use \Exception;

/**
 * Extends by Cards. 
 * When you add new kind of Card class you should extend it by BoardingCardAbstract.
 */
abstract class BoardingCardAbstract {
    // implementation
}
